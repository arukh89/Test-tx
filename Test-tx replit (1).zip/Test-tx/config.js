// ganti URL ini kalau backend Replit berubah
const BACKEND_URL = "https://1a4f1f38-1bc5-459f-89d3-7e411642339d-00-8cgu1jweczd6.sisko.replit.dev";

// export untuk Node.js (kalau dibutuhkan)
if (typeof module !== "undefined") {
  module.exports = { BACKEND_URL };
}
